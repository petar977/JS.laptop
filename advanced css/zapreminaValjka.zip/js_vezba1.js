const p = 3.14;
var r = prompt("Unesi poluprecnik osnove valjka: ");
var h = prompt("Unesi visinu valjka: ");
var h = parseInt(r)*parseInt(r)*p*parseInt(h);
alert ("Zapremina valjka je: " + h);